const express = require('express')
const mongoose = require('mongoose')
const app = express()
require('dotenv').config();
const dbUrl = process.env.dbUrl;
const port = 3000
app.use(express.json())

mongoose.connect(dbUrl,{
    useNewUrlParser:true
}).then(console.log('connected'))
.catch(err=>console.error(err))

const dbSchema = mongoose.Schema({
    title:{
        type:String,
        require:true
    },
    input:{
    type:String,
    require:true
},
})
const product2 = mongoose.model('product2',dbSchema)

//get
app.get('/get',async(req,res)=>{
    const data = await product2.find()
    res.json(data)
})
//get one
app.get('/get/:id',async(req,res)=>{
    const id = req.params.id
    const data = await product2.findById(id)
    const out = JSON.stringify(data.input)
    res.send(out)
})
//add
app.post('/post',async(req,res)=>{
    const newData = new product2({
        title:req.body.title,
        input:req.body.input
    })
    await newData.save()
    .then(res.send('added'))
    .catch(err=>console.error(err))
})
//update
app.put('/put/:id',async(req,res)=>{
    const id = req.params.id
    const updateData = res.body
    await product2.findByIdAndUpdate(id,updateData)
    .then(res.json(updateData))
    .catch(err=>console.error(err))

})
//update single
app.patch('/patch/:id',async(req,res)=>{
    const id = req.params.id
    const updateData = res.body
    await product2.findByIdAndUpdate(id,updateData)
    .then(res.json(updateData))
    .catch(err=>console.error(err))

})
//delete
app.delete('/delete/:id',async(req,res)=>{
    const id = req.params.id
    await product2.findByIdAndDelete(id)
    .then(res.send('deleted'))
    .catch(err=>console.error(err))
})
app.listen(port,console.log(`listening at port ${port}`))