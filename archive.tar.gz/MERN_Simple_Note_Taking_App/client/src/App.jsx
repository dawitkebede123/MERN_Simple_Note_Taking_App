import {useState, useEffect} from 'react'
import axios from 'axios'
import {
  Heading,
  Box,
  Input,
  Button,
  ChakraProvider,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
} from '@chakra-ui/react'

function App() {
  const [title, setTitle] = useState('')
  const [input, setInput] = useState('')
  const [item, setItem] = useState([])
  //const [accordionText, setAccordionText] = useState('')
  const read = '/get'
  const write = '/post'
 
const writeIt = ()=>{


axios.post(write,{title:title,input:input},{headers:{
  "Content-Type": "application/json"}
})
.then(res=>{
 // alert(res.data)
})
.catch(err=>console.error(err))
}
///
const readIt=()=>{
  axios.get(read)
  .then(res=>
    setItem(res.data))
  .catch(err=>console.error(err))

}
  
useEffect(()=>{
  readIt()
},)
  return (
    <ChakraProvider>
      <Heading as='h1'>My memo</Heading>
      <Box p={4} w={'sm'}>
   <Input m={2} p={3} placeholder='title' onChange={event=>{setTitle(event.target.value)}}/>
   <Input m={2} p={3} placeholder='text here' onChange={event=>{setInput(event.target.value)}}/>
   </Box>
   <Button m={2} onClick={writeIt}>Insert</Button>
<Accordion allowToggle>
  {
    item.map(item=>{
      return(
<AccordionItem m={2} backgroundColor='gray.300'>
    <h2>
      <AccordionButton>
        <Box as="span" flex='1' textAlign='left'>
        {item.title}
        </Box>
        <AccordionIcon />
      </AccordionButton>
    </h2>
    <AccordionPanel pb={4}>
      {item.input}
    </AccordionPanel>
  </AccordionItem>)
    })
  }
  
</Accordion>
    </ChakraProvider>
      

  )
}

export default App
